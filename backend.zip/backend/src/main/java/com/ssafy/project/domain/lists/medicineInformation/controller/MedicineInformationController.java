package com.ssafy.project.domain.lists.medicineInformation.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class MedicineInformationController {
}
