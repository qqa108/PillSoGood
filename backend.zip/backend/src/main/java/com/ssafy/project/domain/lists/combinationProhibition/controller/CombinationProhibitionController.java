package com.ssafy.project.domain.lists.combinationProhibition.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class CombinationProhibitionController {
}
