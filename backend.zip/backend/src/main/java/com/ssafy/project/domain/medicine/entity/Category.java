package com.ssafy.project.domain.medicine.entity;

public enum Category {
    전문, 일반, 기타
}
