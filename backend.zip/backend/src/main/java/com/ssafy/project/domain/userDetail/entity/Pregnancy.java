package com.ssafy.project.domain.userDetail.entity;

public enum Pregnancy {
    NONE, POSSIBLE, PREGNANT, NURSING, NURSING_PREGNANT
    // 임신x, 임신 가능성 존재, 임신중, 임신x수유중, 임신o수유중
}
