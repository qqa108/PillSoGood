package com.ssafy.project.domain.lists.amountProhibition.entity;

public enum Field {
    μg, mg, g
}
