package com.ssafy.project.domain.lists.ageProhibition.entity;

public enum AgeField {
    주, 개월, 세
}
