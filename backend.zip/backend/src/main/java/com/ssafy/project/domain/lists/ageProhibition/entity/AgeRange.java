package com.ssafy.project.domain.lists.ageProhibition.entity;

public enum AgeRange {
    미만, 이하, 초과, 이상
}
