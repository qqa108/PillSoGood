package com.ssafy.project.domain.lists.amountProhibition.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class AmountProhibitionController {
}
