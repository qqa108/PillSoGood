package com.ssafy.project.domain.userDetail.entity;

public enum Gender {
    남자,여자 //1,2
}
