package com.ssafy.project.domain.userMedication.entity;

public enum Status {
    TAKING, STOPPED, COMPLETED// 복용x, 복용중, 복용중단, 복용완료
}
