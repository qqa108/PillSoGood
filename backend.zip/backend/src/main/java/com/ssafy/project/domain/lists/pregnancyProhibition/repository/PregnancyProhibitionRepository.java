package com.ssafy.project.domain.lists.pregnancyProhibition.repository;

import org.springframework.stereotype.Repository;

@Repository
public class PregnancyProhibitionRepository {
}
